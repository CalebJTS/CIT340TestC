using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerData
{
    public int Crystal;
    public bool Lazer;
    public float[] position;

    public PlayerData (PlayerControls player)
    {
        //Lazer = player.laserUnlocked;
    }
}

